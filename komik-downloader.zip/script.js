let images = [];

function loadImages() {
  const input = document.getElementById("urlInput").value;
  const urls = input.split(",").map(u => u.trim()).filter(u => u);
  const preview = document.getElementById("preview");
  preview.innerHTML = "";
  images = [];

  urls.forEach((url, index) => {
    const img = new Image();
    img.crossOrigin = "Anonymous";
    img.src = url;
    img.onload = () => {
      images.push({img, index});
    };
    preview.appendChild(img);
  });
}

async function stitchImages() {
  const stitched = [];
  for (let {img, index} of images.sort((a, b) => a.index - b.index)) {
    const canvas = document.createElement("canvas");
    canvas.width = img.width;
    canvas.height = img.height;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0);
    const blob = await new Promise(resolve => canvas.toBlob(resolve));
    stitched.push({blob, index});
  }
  return stitched;
}

async function downloadZip() {
  if (images.length === 0) {
    alert("Belum ada gambar dimuat!");
    return;
  }

  const zip = new JSZip();
  const stitched = await stitchImages();

  stitched.forEach(({blob, index}, i) => {
    zip.file(`page-${i+1}.jpg`, blob);
  });

  const content = await zip.generateAsync({type: "blob"});
  saveAs(content, "komik.zip");
}